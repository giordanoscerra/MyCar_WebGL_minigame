



/*
the FollowFromUpCamera always look at the car from a position abova right over the car
*/
FollowFromUpCamera = function(){

  /* the only data it needs is the position of the camera */
  this.frame = glMatrix.mat4.create();
  
  /* update the camera with the current car position */
  this.update = function(car_position){
    this.frame = car_position;
  }

  /* return the transformation matrix to transform from worlod coordiantes to the view reference frame */
  this.matrix = function(){
    let eye = glMatrix.vec3.create();
    let target = glMatrix.vec3.create();
    let up = glMatrix.vec4.create();
    
    glMatrix.vec3.transformMat4(eye, [0  ,50,0], this.frame);
    glMatrix.vec3.transformMat4(target, [0.0,0.0,0.0,1.0], this.frame);
    glMatrix.vec4.transformMat4(up, [0.0,0.0,-1,0.0], this.frame);
    
    return glMatrix.mat4.lookAt(glMatrix.mat4.create(),eye,target,up.slice(0,3));	
  }
}

/*
the ChaseCamera always look at the car from behind the car, slightly above
*/
ChaseCamera = function(){

  /* the only data it needs is the frame of the camera */
  this.frame = [0,0,0];
  
  /* update the camera with the current car position */
  this.update = function(car_frame){
    this.frame = car_frame.slice();
  }

  /* return the transformation matrix to transform from worlod coordiantes to the view reference frame */
  this.matrix = function(){
    let eye = glMatrix.vec3.create();
    let target = glMatrix.vec3.create();
    glMatrix.vec3.transformMat4(eye, [0  ,2,5,1.0], this.frame);
    glMatrix.vec3.transformMat4(target, [0.0,0.0,0.0,1.0], this.frame);
    return glMatrix.mat4.lookAt(glMatrix.mat4.create(),eye, target,[0, 1, 0]);	
  }
}

//front camera
FrontCamera = function(){

  /* the only data it needs is the frame of the camera */
  this.frame = [0,0,0];
  
  /* update the camera with the current car position */
  this.update = function(car_frame){
    this.frame = car_frame.slice();
  }

  /* return the transformation matrix to transform from worlod coordiantes to the view reference frame */
  this.matrix = function(){
    let eye = glMatrix.vec3.create();
    let target = glMatrix.vec3.create();
    glMatrix.vec3.transformMat4(eye, [0  ,2,-5,1.0], this.frame);
    glMatrix.vec3.transformMat4(target, [0.0,0.0,0.0,1.0], this.frame);
    return glMatrix.mat4.lookAt(glMatrix.mat4.create(),eye, target,[0, 1, 0]);	
  }
}

R_Side_Camera = function(){

  /* the only data it needs is the frame of the camera */
  this.frame = [0,0,0];
  
  /* update the camera with the current car position */
  this.update = function(car_frame){
    this.frame = car_frame.slice();
  }

  /* return the transformation matrix to transform from worlod coordiantes to the view reference frame */
  this.matrix = function(){
    let eye = glMatrix.vec3.create();
    let target = glMatrix.vec3.create();
    glMatrix.vec3.transformMat4(eye, [8  ,1,0,1.0], this.frame);
    glMatrix.vec3.transformMat4(target, [0.0,0.0,0.0,1.0], this.frame);
    return glMatrix.mat4.lookAt(glMatrix.mat4.create(),eye, target,[0, 1, 0]);	
  }
}

L_Side_Camera = function(){

  /* the only data it needs is the frame of the camera */
  this.frame = [0,0,0];
  
  /* update the camera with the current car position */
  this.update = function(car_frame){
    this.frame = car_frame.slice();
  }

  /* return the transformation matrix to transform from worlod coordiantes to the view reference frame */
  this.matrix = function(){
    let eye = glMatrix.vec3.create();
    let target = glMatrix.vec3.create();
    glMatrix.vec3.transformMat4(eye, [-8  ,1,0,1.0], this.frame);
    glMatrix.vec3.transformMat4(target, [0.0,0.0,0.0,1.0], this.frame);
    return glMatrix.mat4.lookAt(glMatrix.mat4.create(),eye, target,[0, 1, 0]);	
  }
}

Headlights_VF = function(){

  /* the only data it needs is the frame of the camera */
  this.frame = [0,0,0];
  
  /* update the camera with the current car position */
  this.update = function(car_frame){
    this.frame = car_frame.slice();
  }

  /* return the transformation matrix to transform from worlod coordiantes to the view reference frame */
  this.matrix = function(){
    let eye = glMatrix.vec3.create();
    let target = glMatrix.vec3.create();
    glMatrix.vec3.transformMat4(eye, [0  ,0,5 ,-2.0 ,1.0], this.car.frame);
    glMatrix.vec3.transformMat4(target, [0.0,0.0,0.0,1.0], this.car.frame);  // z = -4? cit il tizio
    return glMatrix.mat4.lookAt(glMatrix.mat4.create(),eye, target,[0, 1, 0]);	
  }
}

/* the main object to be implementd */
var Renderer = new Object();

/* array of cameras that will be used */
Renderer.cameras = [];
// add a FollowFromUpCamera
Renderer.cameras.push(new FollowFromUpCamera());
Renderer.cameras.push(new ChaseCamera());
Renderer.cameras.push(new FrontCamera());
Renderer.cameras.push(new R_Side_Camera());
Renderer.cameras.push(new L_Side_Camera());

// set the camera currently in use
Renderer.currentCamera = 0;

/*
create the buffers for an object as specified in common/shapes/triangle.js
*/
Renderer.createObjectBuffers = function (gl, obj) {

  obj.vertexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, obj.vertexBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, obj.vertices, gl.STATIC_DRAW);
  gl.bindBuffer(gl.ARRAY_BUFFER, null);

	if(typeof obj.texCoords != 'undefined'){
    		obj.texCoordsBuffer = gl.createBuffer();
    		gl.bindBuffer(gl.ARRAY_BUFFER, obj.texCoordsBuffer);
    		gl.bufferData(gl.ARRAY_BUFFER, obj.texCoords, gl.STATIC_DRAW);
    		gl.bindBuffer(gl.ARRAY_BUFFER, null);
		}

   if(typeof obj.tangents != 'undefined'){ 
       obj.tangentsBuffer = gl.createBuffer();
      	gl.bindBuffer(gl.ARRAY_BUFFER, obj.tangentsBuffer);
      	gl.bufferData(gl.ARRAY_BUFFER, obj.tangents, gl.STATIC_DRAW);
      	gl.bindBuffer(gl.ARRAY_BUFFER, null);
    }
     
     if(typeof obj.normals != 'undefined'){
		  	obj.normalBuffer = gl.createBuffer();
 		 		gl.bindBuffer(gl.ARRAY_BUFFER, obj.normalBuffer);
 		 		gl.bufferData(gl.ARRAY_BUFFER, obj.normals, gl.STATIC_DRAW);
  			gl.bindBuffer(gl.ARRAY_BUFFER, null);
  			}
    	
  obj.indexBufferTriangles = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, obj.indexBufferTriangles);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, obj.triangleIndices, gl.STATIC_DRAW);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, null);

  // create edges
  var edges = new Uint16Array(obj.numTriangles * 3 * 2);
  for (var i = 0; i < obj.numTriangles; ++i) {
    edges[i * 6 + 0] = obj.triangleIndices[i * 3 + 0];
    edges[i * 6 + 1] = obj.triangleIndices[i * 3 + 1];
    edges[i * 6 + 2] = obj.triangleIndices[i * 3 + 0];
    edges[i * 6 + 3] = obj.triangleIndices[i * 3 + 2];
    edges[i * 6 + 4] = obj.triangleIndices[i * 3 + 1];
    edges[i * 6 + 5] = obj.triangleIndices[i * 3 + 2];
  }

  obj.indexBufferEdges = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, obj.indexBufferEdges);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, edges, gl.STATIC_DRAW);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, null);
};

/*
draw an object as specified in common/shapes/triangle.js for which the buffer 
have alrady been created
*/
Renderer.drawObject = function (gl, obj, fillColor, lineColor) {

  gl.bindBuffer(gl.ARRAY_BUFFER, obj.vertexBuffer);
  gl.enableVertexAttribArray(this.uniformShader.aPositionIndex);
  gl.vertexAttribPointer(this.uniformShader.aPositionIndex,3, gl.FLOAT, false, 0, 0);

	if(typeof obj.texCoords != 'undefined'){
	  	gl.bindBuffer(gl.ARRAY_BUFFER, obj.texCoordsBuffer);	
  		gl.enableVertexAttribArray(this.uniformShader.aTexCoordsIndex);
  		gl.vertexAttribPointer(this.uniformShader.aTexCoordsIndex, 2, gl.FLOAT, false, 0, 0);
	}

  if( typeof obj.tangentsBuffer != 'undefined'){ 
     gl.bindBuffer(gl.ARRAY_BUFFER, obj.tangentsBuffer);
    	gl.enableVertexAttribArray(this.uniformShader.aTangentsIndex);
    	gl.vertexAttribPointer(this.uniformShader.aTangentsIndex, 3, gl.FLOAT, false, 0, 0);
  }
    
  gl.enable(gl.POLYGON_OFFSET_FILL);
  gl.polygonOffset(1.0, 1.0);

  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, obj.indexBufferTriangles);
  gl.uniform4fv(this.uniformShader.uColorLocation, fillColor);
  gl.drawElements(gl.TRIANGLES, obj.triangleIndices.length, gl.UNSIGNED_SHORT, 0);

  gl.disable(gl.POLYGON_OFFSET_FILL);
  
  gl.uniform4fv(this.uniformShader.uColorLocation, lineColor);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, obj.indexBufferEdges);
  gl.drawElements(gl.LINES, obj.numTriangles * 3 * 2, gl.UNSIGNED_SHORT, 0);

  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, null);
  gl.disableVertexAttribArray(this.uniformShader.aPositionIndex);
  gl.bindBuffer(gl.ARRAY_BUFFER, null);
};

/*
initialize the object in the scene
*/
Renderer.initializeObjects = function (gl) {
  speedWheelAngle = 0;
  Game.setScene(scene_0);
  this.car = Game.addCar("mycar");
  lamps = Game.scene.lamps;
  Renderer.triangle = new Triangle();

  this.cube = new Cube(10);
  this.createObjectBuffers(gl,this.cube);
  
  this.cylinder = new Cylinder(10);
  this.createObjectBuffers(gl,this.cylinder );
  
  Renderer.createObjectBuffers(gl, this.triangle);

  Renderer.createObjectBuffers(gl,Game.scene.trackObj);
  Renderer.createObjectBuffers(gl,Game.scene.groundObj);
  for (var i = 0; i < Game.scene.buildings.length; ++i) { 
	  	Renderer.createObjectBuffers(gl,Game.scene.buildingsObjTex[i]);
	  	Renderer.createObjectBuffers(gl,Game.scene.buildingsObjTex[i].roof);
	  	}
	  	
	Renderer.loadTexture(gl,0,"../common/textures/street4.png");
	Renderer.loadTexture(gl,1,"../common/textures/facade2.jpg");
	Renderer.loadTexture(gl,2,"../common/textures/roof.jpg");
	Renderer.loadTexture(gl,3,"../common/textures/grass_tile.png");
  Renderer.loadTexture(gl,4,"../common/textures/pizza.jpg");
  Renderer.loadTexture(gl,5,"../common/textures/ruota.jfif");
  Renderer.loadTexture(gl,6,"../common/textures/formaggio.jpg");
  Renderer.loadTexture(gl,7,"../common/textures/headlight.png");
  
};

	Renderer.loadTexture = function (gl,tu, url){
	var image = new Image();
	image.src = url;
	image.addEventListener('load',function(){	
		gl.activeTexture(gl.TEXTURE0+tu);
		var texture = gl.createTexture();
		gl.bindTexture(gl.TEXTURE_2D,texture);
    if(tu == 7) {
      gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,image);
    }
    else {
      gl.texImage2D(gl.TEXTURE_2D,0,gl.RGB,gl.RGB,gl.UNSIGNED_BYTE,image);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.REPEAT);
		  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.REPEAT);
    }
		
		gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
			gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR)
		//gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_NEAREST);
		//gl.generateMipmap(gl.TEXTURE_2D);
		});
    
	}


/*
draw the car
*/
Renderer.drawCar = function (gl) {

    M                 = glMatrix.mat4.create();
    rotate_transform  = glMatrix.mat4.create();
    translate_matrix  = glMatrix.mat4.create();
    scale_matrix      = glMatrix.mat4.create();
  rotation_curve = glMatrix.mat4.create();
    // Create a rotation matrix that rotates the wheels along the y axis of Renderer.car.wheelsAngle radians
    glMatrix.mat4.fromRotation(rotation_curve, Renderer.car.wheelsAngle * 2, [0, 1, 0]); //il *2 perchè si vede meglio
  
    glMatrix.mat4.fromTranslation(translate_matrix,[0,1,1]);
    glMatrix.mat4.fromScaling(scale_matrix,[0.7,0.25,1]);
    glMatrix.mat4.mul(M,scale_matrix,translate_matrix);
    //glMatrix.mat4.fromRotation(rotate_transform,-0.1,[1,0,0]);
    //glMatrix.mat4.mul(M,rotate_transform,M);
    glMatrix.mat4.fromTranslation(translate_matrix,[0,0.1,-1]);
    glMatrix.mat4.mul(M,translate_matrix,M);

    Renderer.stack.push();
    Renderer.stack.multiply(M);
    gl.uniformMatrix4fv(this.uniformShader.uModelViewMatrixLocation, false, this.stack.matrix);
    gl.uniform1i(this.uniformShader.uSamplerLocation,4);
    this.drawObject(gl,this.cube,[0.803, 0.784, 0.756, 1],[0.803, 0.784, 0.756,1]);
    Renderer.stack.pop();
  //testa papera
    M = glMatrix.mat4.identity(M); 
    glMatrix.mat4.fromTranslation(translate_matrix,[0,2.2,-1]);
    glMatrix.mat4.fromScaling(scale_matrix,[0.5,0.5,0.5]);
    glMatrix.mat4.mul(M,scale_matrix,translate_matrix);
  glMatrix.mat4.mul(M, rotation_curve, M)
  
  Renderer.stack.push();
    Renderer.stack.multiply(M);
    gl.uniformMatrix4fv(this.uniformShader.uModelViewMatrixLocation, false, this.stack.matrix);
    gl.uniform1i(this.uniformShader.uSamplerLocation,4);
    this.drawObject(gl,this.cube,[0.839, 0.796, 0.741, 1],[0.839, 0.796, 0.741, 1]);
    Renderer.stack.pop();

  //becco papera
  M = glMatrix.mat4.identity(M); 
    glMatrix.mat4.fromTranslation(translate_matrix,[0,23,-6]);
    glMatrix.mat4.fromScaling(scale_matrix,[0.5,0.05,0.2]);
    glMatrix.mat4.mul(M,scale_matrix,translate_matrix);
  glMatrix.mat4.mul(M, rotation_curve, M)
  Renderer.stack.push();
    Renderer.stack.multiply(M);
    gl.uniformMatrix4fv(this.uniformShader.uModelViewMatrixLocation, false, this.stack.matrix);
    gl.uniform1i(this.uniformShader.uSamplerLocation,6);
    this.drawObject(gl,this.cube,[0.929, 0.537, 0.047, 1],[0.929, 0.537, 0.047,1]);
    Renderer.stack.pop();

  //occhio sx papera
  glMatrix.mat4.identity(M);
  Me                 = glMatrix.mat4.create();
  glMatrix.mat4.fromRotation(rotate_transform,3.14/2.0,[1,0,0]);
    glMatrix.mat4.fromTranslation(translate_matrix,[0,0,0]);
    glMatrix.mat4.mul(Me,translate_matrix,rotate_transform);
    
    glMatrix.mat4.fromScaling(scale_matrix,[0.1,0.1,0.01]);
    glMatrix.mat4.mul(Me,scale_matrix,Me);


    
    glMatrix.mat4.fromTranslation(translate_matrix,[-0.4,1.4,-1.05]);
    glMatrix.mat4.mul(M,translate_matrix,Me);
  glMatrix.mat4.mul(M, rotation_curve, M)

    Renderer.stack.push();
    Renderer.stack.multiply(M);
    gl.uniformMatrix4fv(this.uniformShader.uModelViewMatrixLocation, false, this.stack.matrix);
    gl.uniform1i(this.uniformShader.uSamplerLocation,7);
    this.drawObject(gl,this.cylinder,[0., 0., 0.,1.0],[0., 0., 0.,1.0]);
    Renderer.stack.pop();

  //occhio dx papera
  glMatrix.mat4.identity(M);
  Me                 = glMatrix.mat4.create();
  glMatrix.mat4.fromRotation(rotate_transform,3.14/2.0,[1,0,0]);
    glMatrix.mat4.fromTranslation(translate_matrix,[0,0,0]);
    glMatrix.mat4.mul(Me,translate_matrix,rotate_transform);
    
    glMatrix.mat4.fromScaling(scale_matrix,[0.1,0.1,0.01]);
    glMatrix.mat4.mul(Me,scale_matrix,Me);

    glMatrix.mat4.fromTranslation(translate_matrix,[0.4,1.4,-1.05]);
    glMatrix.mat4.mul(M,translate_matrix,Me);
  glMatrix.mat4.mul(M, rotation_curve, M)

    Renderer.stack.push();
    Renderer.stack.multiply(M);
    gl.uniformMatrix4fv(this.uniformShader.uModelViewMatrixLocation, false, this.stack.matrix);
    gl.uniform1i(this.uniformShader.uSamplerLocation,7);
    this.drawObject(gl,this.cylinder,[0., 0., 0.,1.0],[0., 0., 0.,1.0]);
    Renderer.stack.pop();

  //ruote
    Mw                 = glMatrix.mat4.create();
    /* draw the wheels */
    glMatrix.mat4.fromRotation(rotate_transform,3.14/2.0,[0,0,1]);
    glMatrix.mat4.fromTranslation(translate_matrix,[1,0,0]);
    glMatrix.mat4.mul(Mw,translate_matrix,rotate_transform);
    glMatrix.mat4.fromScaling(scale_matrix,[0.1,0.2,0.2]);
    glMatrix.mat4.mul(Mw,scale_matrix,Mw);
     /* now the diameter of the wheel is 2*0.2 = 0.4 and the wheel is centered in 0,0,0 */
  
  speedWheelAngle += Renderer.car.speed;
    if(speedWheelAngle > 3.14 * 2){ //una rotazione di K*Pi = rotazione di Pi
      speedWheelAngle -= 3.14 * 2;
    }else if (speedWheelAngle < - (3.14 * 2)){
      speedWheelAngle += 3.14 * 2;
    }
    speedBasedRotationMatrix = glMatrix.mat4.create();
    glMatrix.mat4.fromRotation(speedBasedRotationMatrix, speedWheelAngle, [-1, 0, 0]);
    glMatrix.mat4.mul(Mw, speedBasedRotationMatrix, Mw);

     
    glMatrix.mat4.identity(M);
    
    glMatrix.mat4.fromTranslation(translate_matrix,[-0.8,0.2,-0.7]);
   glMatrix.mat4.mul(M, rotation_curve, Mw)
    glMatrix.mat4.mul(M,translate_matrix,M);

    Renderer.stack.push();
    Renderer.stack.multiply(M);
    gl.uniformMatrix4fv(this.uniformShader.uModelViewMatrixLocation, false, this.stack.matrix);
  //ruota davanti sx
  gl.uniform1i(this.uniformShader.uSamplerLocation,5);
    this.drawObject(gl,this.cylinder,[0.929, 0.537, 0.047,1.0],[0.9, 0.5, 0,1.0]);
    Renderer.stack.pop();

    glMatrix.mat4.fromTranslation(translate_matrix,[0.8,0.2,-0.7]);
  glMatrix.mat4.mul(M, rotation_curve, Mw)
    glMatrix.mat4.mul(M,translate_matrix,M);

    Renderer.stack.push();
    Renderer.stack.multiply(M);
    gl.uniformMatrix4fv(this.uniformShader.uModelViewMatrixLocation, false, this.stack.matrix); 
  //ruota davanti dx
  gl.uniform1i(this.uniformShader.uSamplerLocation,5);
  this.drawObject(gl,this.cylinder,[0.929, 0.537, 0.047,1.0],[0.9, 0.5, 0,1.0]);
    Renderer.stack.pop();

    /* this will increase the size of the wheel to 0.4*1,5=0.6 */
    glMatrix.mat4.fromScaling(scale_matrix,[1,1.5,1.5]);;
    glMatrix.mat4.mul(Mw,scale_matrix,Mw);
    
    glMatrix.mat4.fromTranslation(translate_matrix,[0.8,0.3,0.7]);
    glMatrix.mat4.mul(M,translate_matrix,Mw);
  
    Renderer.stack.push();
    Renderer.stack.multiply(M);
    gl.uniformMatrix4fv(this.uniformShader.uModelViewMatrixLocation, false, this.stack.matrix); 
    Renderer.stack.pop();
    //ruota dietro dx
  gl.uniform1i(this.uniformShader.uSamplerLocation,5);
    this.drawObject(gl,this.cylinder,[0.929, 0.537, 0.047,1.0],[0.9, 0.5, 0,1.0]);

    glMatrix.mat4.fromTranslation(translate_matrix,[-0.8,0.3,0.7]);
    glMatrix.mat4.mul(M,translate_matrix,Mw);
  
    Renderer.stack.push();
    Renderer.stack.multiply(M);
    gl.uniformMatrix4fv(this.uniformShader.uModelViewMatrixLocation, false, this.stack.matrix); 
  //ruota dietro sx
  gl.uniform1i(this.uniformShader.uSamplerLocation,5);
    this.drawObject(gl,this.cylinder,[0.929, 0.537, 0.047,1.0],[0.9, 0.5, 0,1.0]);
    Renderer.stack.pop();

  
  
};


Renderer.drawScene = function (gl) {

	
	gl.enable(gl.CULL_FACE);

  var width = this.canvas.width;
  var height = this.canvas.height
  var ratio = width / height;
  this.stack = new MatrixStack();

  gl.viewport(0, 0, width, height);
  
  gl.enable(gl.DEPTH_TEST);

  // Clear the framebuffer
  gl.clearColor(0.34, 0.5, 0.74, 1.0);
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);


  gl.useProgram(this.uniformShader);
  
  gl.uniformMatrix4fv(this.uniformShader.uProjectionMatrixLocation,     false,glMatrix.mat4.perspective(glMatrix.mat4.create(),3.14 / 4, ratio, 1, 500));

  Renderer.cameras[Renderer.currentCamera].update(this.car.frame);

  var invV = Renderer.cameras[Renderer.currentCamera].matrix();
  
  // initialize the stack with the identity
  this.stack.loadIdentity();
  // multiply by the view matrix
  this.stack.multiply(invV);

  // drawing the car
  this.stack.push();
  this.stack.multiply(this.car.frame); // projection * viewport
  //gl.uniformMatrix4fv(this.uniformShader.uModelViewMatrixLocation, false, stack.matrix);
  this.drawCar(gl);
  this.stack.pop();

  gl.uniformMatrix4fv(this.uniformShader.uModelViewMatrixLocation, false, this.stack.matrix);
  
//FARETTI MACHINA
  
  var eye = glMatrix.vec3.create();
  var target = glMatrix.vec3.create();
  glMatrix.vec3.transformMat4(eye, [0, 0.5, -1], this.car.frame);
  glMatrix.vec3.transformMat4(target, [0, 0.1, -6], this.car.frame);  
  var HeadlightViewMatrix = glMatrix.mat4.lookAt(glMatrix.mat4.create(),eye, target,[0, 1, 0]);	
  gl.uniform1i(this.uniformShader.uHeadlightSamplerLocation, 7);
  gl.uniformMatrix4fv(this.uniformShader.uHeadlightViewMatrixLocation, false, HeadlightViewMatrix);
  gl.uniformMatrix4fv(this.uniformShader.uHeadlightProjectionMatrixLocation, false, glMatrix.mat4.perspective(glMatrix.mat4.create(),3.14 / 10, 1, 1, 50));

  
  // drawing the static elements (ground, track and buldings)
	gl.uniform1i(this.uniformShader.uSamplerLocation,3);
	this.drawObject(gl, Game.scene.groundObj, [0.3, 0.7, 0.2, 1.0], [0, 0, 0, 1.0]);
	
	gl.uniform1i(this.uniformShader.uSamplerLocation,0);
 	this.drawObject(gl, Game.scene.trackObj, [0.9, 0.8, 0.7, 1.0], [0, 0, 0, 1.0]);
 	
 	
	gl.uniform1i(this.uniformShader.uSamplerLocation,1);
	for (var i in Game.scene.buildingsObj) 
		this.drawObject(gl, Game.scene.buildingsObjTex[i], [0.8, 0.8, 0.8, 1.0], [0.2, 0.2, 0.2, 1.0]);
	gl.uniform1i(this.uniformShader.uSamplerLocation,2);
  for (var i in Game.scene.buildingsObj) 
		this.drawObject(gl, Game.scene.buildingsObjTex[i].roof, [0.8, 0.8, 0.8, 1.0], [0.2, 0.2, 0.2, 1.0]);

  
		
	gl.useProgram(null);
};



Renderer.Display = function () {
  Renderer.drawScene(Renderer.gl);
  window.requestAnimationFrame(Renderer.Display) ;
};


Renderer.setupAndStart = function () {
 /* create the canvas */
	Renderer.canvas = document.getElementById("OUTPUT-CANVAS");
  
 /* get the webgl context */
	Renderer.gl = Renderer.canvas.getContext("webgl");

  /* read the webgl version and log */
	var gl_version = Renderer.gl.getParameter(Renderer.gl.VERSION); 
	log("glversion: " + gl_version);
	var GLSL_version = Renderer.gl.getParameter(Renderer.gl.SHADING_LANGUAGE_VERSION)
	log("glsl  version: "+GLSL_version);

  /* create the matrix stack */
	Renderer.stack = new MatrixStack();

  /* initialize objects to be rendered */
  Renderer.initializeObjects(Renderer.gl);

  /* create the shader */
  Renderer.uniformShader = new uniformShader(Renderer.gl);

  /*
  add listeners for the mouse / keyboard events
  */
  Renderer.canvas.addEventListener('mousemove',on_mouseMove,false);
  Renderer.canvas.addEventListener('keydown',on_keydown,false);
  Renderer.canvas.addEventListener('keyup',on_keyup,false);

  Renderer.Display();
}

on_mouseMove = function(e){}

on_keyup = function(e){
	Renderer.car.control_keys[e.key] = false;
}
on_keydown = function(e){
	Renderer.car.control_keys[e.key] = true;
}

window.onload = Renderer.setupAndStart;


update_camera = function (value){
  Renderer.currentCamera = value;
}
